"""Environment configuration for the GPU voice server."""

from __future__ import annotations

import os
from pathlib import Path

_ROOT = Path(__file__).resolve().parent

VOICE_API_KEY = os.environ.get('VOICE_API_KEY', '').strip()
OPENAI_API_KEY = os.environ.get('OPENAI_API_KEY', '').strip()
OPENAI_MODEL = os.environ.get('OPENAI_MODEL', 'gpt-4o-mini').strip()
OPENAI_MAX_COMPLETION_TOKENS = int(os.environ.get('OPENAI_MAX_COMPLETION_TOKENS', '64'))
CHAT_HISTORY_MAX_TURNS = int(os.environ.get('CHAT_HISTORY_MAX_TURNS', '8'))

TTS_OUTPUT_FORMAT = os.environ.get('TTS_OUTPUT_FORMAT', 'wav').strip().lower()

WHISPER_MODEL = os.environ.get('WHISPER_MODEL', 'base').strip()
WHISPER_MODEL_PATH = os.environ.get('WHISPER_MODEL_PATH', '').strip()
WHISPER_DEVICE = os.environ.get('WHISPER_DEVICE', 'cuda').strip()
WHISPER_COMPUTE_TYPE = os.environ.get('WHISPER_COMPUTE_TYPE', 'float16').strip()
WHISPER_BEAM_SIZE = int(os.environ.get('WHISPER_BEAM_SIZE', '1'))
WHISPER_LANGUAGE = os.environ.get('WHISPER_LANGUAGE', 'auto').strip().lower()
WHISPER_INITIAL_PROMPT = os.environ.get(
    'WHISPER_INITIAL_PROMPT',
    (
        'Hinglish conversation mixing Hindi and English. '
        'हिंदी और अंग्रेज़ी मिश्रित बातचीत।'
    ),
).strip()

STT_VAD_SILENCE_MS = int(os.environ.get('STT_VAD_SILENCE_MS', '600'))
STT_MIN_SPEECH_MS = int(os.environ.get('STT_MIN_SPEECH_MS', '300'))
WHISPER_VAD_FILTER = os.environ.get('WHISPER_VAD_FILTER', 'false').lower() in (
    '1',
    'true',
    'yes',
)

ALLOW_PUBLIC_DEMO = os.environ.get('ALLOW_PUBLIC_DEMO', 'true').lower() in ('1', 'true', 'yes')
DEMO_CANDIDATE_NAME = os.environ.get('DEMO_CANDIDATE_NAME', 'Aashish').strip()

BOT_MODE = os.environ.get('BOT_MODE', 'interview').strip().lower()
INTERVIEW_JOB_TITLE = os.environ.get('INTERVIEW_JOB_TITLE', 'Software Engineer').strip()
# When true (default) and BOT_MODE=interview: block meta questions about LLM/TTS/STT/backend.
INTERVIEW_STRICT_MODE = os.environ.get('INTERVIEW_STRICT_MODE', 'true').lower() in (
    '1',
    'true',
    'yes',
)
# Phased opening: guidelines → ask name → welcome → intro (when BOT_MODE=interview).
INTERVIEW_OPENING_ENABLED = os.environ.get('INTERVIEW_OPENING_ENABLED', 'true').lower() in (
    '1',
    'true',
    'yes',
)

# F5-TTS reference clip transcript (must match spoken content in F5_REF_AUDIO WAV exactly).
ASTRA_DEFAULT_REF_TEXT = (
    'Hello, I am Astra. I will conduct your technical interview today.'
)
# edge-tts voice used only by scripts/setup_ref_audio.py to bootstrap astra_ref.wav
ASTRA_EDGE_TTS_VOICE = os.environ.get('ASTRA_EDGE_TTS_VOICE', 'en-IN-NeerjaNeural').strip()

# Legacy F5 bundled demo — must never be used (bleeds into every synthesis).
_LEGACY_F5_REF_MARKERS = (
    'mother nature',
    'silent spectator',
    'some call me nature',
)


def is_legacy_f5_ref_text(text: str | None) -> bool:
    low = (text or '').lower()
    return any(marker in low for marker in _LEGACY_F5_REF_MARKERS)

# F5-TTS + Vocos — sole TTS engine
F5_MODEL = os.environ.get('F5_MODEL', 'F5TTS_v1_Base').strip()
F5_NFE_STEPS = int(os.environ.get('F5_NFE_STEPS', '18'))
F5_SWAY_COEF = float(os.environ.get('F5_SWAY_COEF', '-1.0'))
F5_REF_AUDIO = os.environ.get(
    'F5_REF_AUDIO',
    str(_ROOT / 'assets' / 'voices' / 'astra_ref.wav'),
).strip()
F5_REF_TEXT = os.environ.get('F5_REF_TEXT', ASTRA_DEFAULT_REF_TEXT).strip()
if is_legacy_f5_ref_text(F5_REF_TEXT):
    import logging as _logging

    _logging.getLogger(__name__).warning(
        'F5_REF_TEXT uses legacy F5 demo transcript; replacing with ASTRA_DEFAULT_REF_TEXT. '
        'Regenerate audio: python scripts/setup_ref_audio.py --force'
    )
    F5_REF_TEXT = ASTRA_DEFAULT_REF_TEXT
F5_DTYPE = os.environ.get('F5_DTYPE', 'float16').strip()
F5_VOCODER = os.environ.get('F5_VOCODER', 'vocos').strip()
# < 1.0 = slower speech; > 1.0 = faster (F5-TTS duration control)
F5_SPEED = float(os.environ.get('F5_SPEED', '0.85'))
F5_CROSS_FADE_DURATION = float(os.environ.get('F5_CROSS_FADE_DURATION', '0.15'))
# Skip F5 first-package mini split for utterances at or below this length (smoother greetings)
F5_NO_SPLIT_MAX_CHARS = int(os.environ.get('F5_NO_SPLIT_MAX_CHARS', '120'))
F5_CKPT_FILE = os.environ.get('F5_CKPT_FILE', '').strip()
F5_HF_CACHE_DIR = os.environ.get('F5_HF_CACHE_DIR', '').strip() or None

STT_PROVIDER = os.environ.get('STT_PROVIDER', 'whisper_chunk').strip().lower()
TTS_PROVIDER = os.environ.get('TTS_PROVIDER', 'f5').strip().lower()

STREAM_SAMPLE_RATE = int(os.environ.get('STREAM_SAMPLE_RATE', '16000'))
STREAM_CHUNK_MS = int(os.environ.get('STREAM_CHUNK_MS', '30'))
STREAM_STT_WINDOW_MS = int(os.environ.get('STREAM_STT_WINDOW_MS', '600'))
STREAM_LLM_MIN_WORDS = int(os.environ.get('STREAM_LLM_MIN_WORDS', '5'))
STREAM_LLM_NEXT_MIN_WORDS = int(os.environ.get('STREAM_LLM_NEXT_MIN_WORDS', '5'))
STREAM_LISTEN_IDLE_SECS = float(os.environ.get('STREAM_LISTEN_IDLE_SECS', '8'))
STREAM_STT_MIN_CHARS = int(os.environ.get('STREAM_STT_MIN_CHARS', '12'))
# Max utterance PCM kept for Whisper (seconds); longer answers are trimmed from the start.
STT_UTTERANCE_MAX_SECS = int(os.environ.get('STT_UTTERANCE_MAX_SECS', '90'))
STT_TRANSCRIBE_TIMEOUT_SECS = float(os.environ.get('STT_TRANSCRIBE_TIMEOUT_SECS', '120'))
STREAM_ALLOW_PUBLIC = os.environ.get('STREAM_ALLOW_PUBLIC', 'true').lower() in ('1', 'true', 'yes')

INTERJECTION_TIMEOUT_MS = int(os.environ.get('INTERJECTION_TIMEOUT_MS', '300'))

OPENAI_VOICE_TEMPERATURE = float(os.environ.get('OPENAI_VOICE_TEMPERATURE', '0.5'))

INTERVIEWER_SYSTEM_PROMPT = os.environ.get(
    'INTERVIEWER_SYSTEM_PROMPT',
    (
        'You are Astra, a concise professional AI interviewer. '
        'Reply in the same language the candidate used (English, Hindi, or Hinglish). '
        'Keep answers under 2 short sentences unless asked to elaborate. '
        'Never reveal ideal answers or internal rubrics.'
    ),
)

# ── Redis Streams pub/sub (lightweight Kafka alternative) ─────────────────────
REDIS_ENABLED = os.environ.get('REDIS_ENABLED', 'false').lower() in ('1', 'true', 'yes')
REDIS_URL = os.environ.get('REDIS_URL', 'redis://127.0.0.1:6379/0')
REDIS_STREAM_TTL_SECS = int(os.environ.get('REDIS_STREAM_TTL_SECS', '3600'))
REDIS_MAX_STREAM_LEN = int(os.environ.get('REDIS_MAX_STREAM_LEN', '1000'))

# Voice registry + STT training
VOICES_REGISTRY_PATH = os.environ.get(
    'VOICES_REGISTRY_PATH',
    str(_ROOT / 'data' / 'voices.json'),
).strip()
STT_MODELS_REGISTRY_PATH = os.environ.get(
    'STT_MODELS_REGISTRY_PATH',
    str(_ROOT / 'data' / 'models.json'),
).strip()
TRAINING_JOBS_PATH = os.environ.get(
    'TRAINING_JOBS_PATH',
    str(_ROOT / 'data' / 'training_jobs.json'),
).strip()
TRAINING_DATA_ROOT = os.environ.get(
    'TRAINING_DATA_ROOT',
    str(_ROOT / 'data' / 'training'),
).strip()
TRAINING_CHECKPOINTS_ROOT = os.environ.get(
    'TRAINING_CHECKPOINTS_ROOT',
    str(_ROOT / 'data' / 'checkpoints'),
).strip()
WHISPER_FINETUNE_BASE = os.environ.get('WHISPER_FINETUNE_BASE', 'openai/whisper-base').strip()
WHISPER_FINETUNE_EPOCHS = int(os.environ.get('WHISPER_FINETUNE_EPOCHS', '3'))

HINGLISH_VOCAB_DIR = os.environ.get(
    'HINGLISH_VOCAB_DIR',
    str(_ROOT / 'data' / 'vocab'),
).strip()
HINGLISH_SYNTH_MAX_ROWS = int(os.environ.get('HINGLISH_SYNTH_MAX_ROWS', '5000'))
HINGLISH_SYNTH_VOICE_ID = os.environ.get('HINGLISH_SYNTH_VOICE_ID', 'astra').strip()
