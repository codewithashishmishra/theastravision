# Voice & STT tuning (Parler-only)

## Recommended `.env` (Salad / free OSS)

```env
BOT_MODE=interview
INTERVIEW_JOB_TITLE=Software Engineer
TTS_PROVIDER=parler
HF_TOKEN=hf_...
PARLER_DEVICE=cuda
PARLER_DTYPE=float16
STT_PROVIDER=whisper_chunk
WHISPER_MODEL=large-v3
WHISPER_LANGUAGE=auto
STREAM_LLM_MIN_WORDS=2
PARLER_MAX_NEW_TOKENS=512
OPENAI_MODEL=gpt-4o-mini
```

Install: `bash scripts/install-parler.sh` (after PyTorch + `requirements.txt`).

## Bot language selector (`/bot`)

The interview UI lets you pick **English** (default), **Hindi**, **Hinglish**, or **Auto**. That locks STT, LLM replies, and Parler captions together for the session.

| UI choice | STT | LLM | TTS |
|-----------|-----|-----|-----|
| English | `language=en` | English only | `PARLER_CAPTION_EN` |
| Hindi | `language=hi` | Devanagari only | `PARLER_CAPTION_HI` (Indian Hindi accent) |
| Hinglish | auto + Hinglish prompt | Mixed | Script-split |
| Auto | Detect from speech | Detect | Detect |

## Indic Parler-TTS captions

Voice persona is controlled by natural-language **captions**, not voice IDs.

| Variable | Purpose |
|----------|---------|
| `PARLER_CAPTION_HI` | Hindi / Devanagari segments (default: calm Divya-style) |
| `PARLER_CAPTION_EN` | English / Latin segments (default: calm Mary-style) |
| `PARLER_MODEL_ID` | Default `ai4bharat/indic-parler-tts` |
| `PARLER_DTYPE` | `float16` on GPU (recommended) |

Example calmer Hindi:

```env
PARLER_CAPTION_HI=Rohit speaks in a calm, clear, moderate-paced professional tone with very clear audio and no background noise.
```

Recommended Hindi speakers in captions: **Rohit**, **Divya**, **Aman**, **Rani** (see [PARLER_TTS.md](docs/PARLER_TTS.md)).

## Technical interviewer mode

`BOT_MODE=interview` uses [`streaming/prompts_interviewer.py`](streaming/prompts_interviewer.py) — one technical question at a time for `INTERVIEW_JOB_TITLE`.

## Whisper

`WHISPER_LANGUAGE=auto` + quoted `WHISPER_INITIAL_PROMPT` for Hinglish STT.
