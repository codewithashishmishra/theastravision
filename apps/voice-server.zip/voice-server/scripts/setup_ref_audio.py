#!/usr/bin/env python3
"""Generate Astra F5 reference audio (do not use F5's bundled 'mother nature' demo clip)."""

from __future__ import annotations

import argparse
import asyncio
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

DEST_DIR = ROOT / 'assets' / 'voices'
DEST = DEST_DIR / 'astra_ref.wav'

# Legacy F5 demo transcript — must not be used (audio bleeds into every synthesis).
_LEGACY_REF_MARKERS = ('silent spectator', 'mother nature', 'some call me nature')

try:
    from config import ASTRA_DEFAULT_REF_TEXT, ASTRA_EDGE_TTS_VOICE
except ImportError:
    ASTRA_DEFAULT_REF_TEXT = (
        'Hello, I am Astra. I will conduct your technical interview today.'
    )
    ASTRA_EDGE_TTS_VOICE = 'en-IN-NeerjaNeural'


async def _generate_with_edge_tts(dest: Path, text: str, voice: str) -> None:
    import edge_tts

    tmp = dest.with_suffix('.mp3')
    await edge_tts.Communicate(text, voice).save(str(tmp))
    try:
        import torch
        import torchaudio

        wav, sr = torchaudio.load(str(tmp))
        if wav.shape[0] > 1:
            wav = wav.mean(dim=0, keepdim=True)
        target_sr = 24000
        if sr != target_sr:
            wav = torchaudio.functional.resample(wav, sr, target_sr)
        torchaudio.save(str(dest), wav, target_sr)
    finally:
        tmp.unlink(missing_ok=True)


def _text_has_legacy_ref(text: str) -> bool:
    low = text.lower()
    return any(marker in low for marker in _LEGACY_REF_MARKERS)


def _registry_has_legacy_text() -> bool:
    reg_path = ROOT / 'data' / 'voices.json'
    if not reg_path.is_file():
        return False
    return _text_has_legacy_ref(reg_path.read_text(encoding='utf-8'))


def _env_has_legacy_text() -> bool:
    env_path = ROOT / '.env'
    if not env_path.is_file():
        return False
    return _text_has_legacy_ref(env_path.read_text(encoding='utf-8'))


def _sync_voices_json(ref_text: str) -> None:
    """Update data/voices.json astra profile after regenerating reference audio."""
    reg_path = ROOT / 'data' / 'voices.json'
    if not reg_path.is_file():
        return
    import json

    data = json.loads(reg_path.read_text(encoding='utf-8'))
    changed = False
    for v in data.get('voices', []):
        if v.get('id') != 'astra':
            continue
        if _text_has_legacy_ref(v.get('ref_text') or ''):
            v['ref_text'] = ref_text
            changed = True
        if v.get('display_name') != 'Astra (Neerja / Indian English)':
            v['display_name'] = 'Astra (Neerja / Indian English)'
            changed = True
        if v.get('language') != 'en-in':
            v['language'] = 'en-in'
            changed = True
        if v.get('source') != 'edge-tts-neerja':
            v['source'] = 'edge-tts-neerja'
            changed = True
    if changed:
        reg_path.write_text(
            json.dumps(data, indent=2, ensure_ascii=False) + '\n',
            encoding='utf-8',
        )
        print(f'Updated astra voice in {reg_path}')


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        '--force',
        action='store_true',
        help='Replace existing astra_ref.wav (required if old F5 demo clip was copied)',
    )
    parser.add_argument(
        '--text',
        default=ASTRA_DEFAULT_REF_TEXT,
        help='Transcript spoken in the generated reference clip',
    )
    parser.add_argument(
        '--voice',
        default=ASTRA_EDGE_TTS_VOICE,
        help='edge-tts voice id (default: en-IN-NeerjaNeural — clear Indian English, Hinglish-friendly)',
    )
    args = parser.parse_args()

    DEST_DIR.mkdir(parents=True, exist_ok=True)

    if DEST.is_file() and not args.force:
        if _registry_has_legacy_text() or _env_has_legacy_text():
            print(
                'Legacy F5 demo reference detected in voices.json or .env. Re-run with --force:\n'
                '  python scripts/setup_ref_audio.py --force'
            )
            raise SystemExit(1)
        print(f'Reference audio already exists: {DEST}')
        print('Use --force to regenerate.')
        return

    if DEST.is_file() and args.force:
        DEST.unlink()

    try:
        import edge_tts  # noqa: F401
    except ImportError:
        print(
            'edge-tts is required to generate reference audio:\n'
            '  pip install edge-tts\n'
            '  python scripts/setup_ref_audio.py --force'
        )
        raise SystemExit(1)

    print(f'Generating reference audio: {DEST}')
    print(f'  text: {args.text}')
    print(f'  voice: {args.voice}')
    asyncio.run(_generate_with_edge_tts(DEST, args.text.strip(), args.voice))
    _sync_voices_json(args.text.strip())

    print(f'Wrote {DEST}')
    print(f'Set in .env: F5_REF_TEXT="{args.text.strip()}"')


if __name__ == '__main__':
    main()
