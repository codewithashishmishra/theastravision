"""F5-TTS streaming worker wrapping hot VRAM voice cache."""

from __future__ import annotations

import asyncio
import logging
from collections.abc import AsyncIterator

from engines.f5_tts_engine import get_manager
from engines.interjections import CachedInterjection
from providers.base import TtsAudioChunk

logger = logging.getLogger(__name__)


class TtsWorker:
    """Async wrapper around synchronous F5-TTS streaming inference."""

    def __init__(self) -> None:
        self._language_hint: str | None = None
        self._voice_id: str | None = None

    async def start(
        self,
        *,
        language_hint: str | None = None,
        voice_id: str | None = None,
    ) -> None:
        self._language_hint = language_hint
        self._voice_id = voice_id
        mgr = get_manager()
        mgr.set_active_voice(voice_id)
        mgr.reset_stream_state()

    async def close(self) -> None:
        pass

    def synthesize_stream(self, text: str) -> AsyncIterator[TtsAudioChunk]:
        return self._stream(text)

    async def _stream(self, text: str) -> AsyncIterator[TtsAudioChunk]:
        cleaned = (text or '').strip()
        if not cleaned:
            return

        loop = asyncio.get_running_loop()
        mgr = get_manager()
        queue: asyncio.Queue[TtsAudioChunk | BaseException | None] = asyncio.Queue(maxsize=64)

        def _producer() -> None:
            try:
                for pcm, sr in mgr.synthesize_stream_sync(cleaned):
                    if pcm:
                        chunk = TtsAudioChunk(pcm_s16le=pcm, sample_rate=sr)
                        fut = asyncio.run_coroutine_threadsafe(queue.put(chunk), loop)
                        fut.result(timeout=120)
            except BaseException as exc:
                asyncio.run_coroutine_threadsafe(queue.put(exc), loop)
            finally:
                asyncio.run_coroutine_threadsafe(queue.put(None), loop)

        loop.run_in_executor(None, _producer)

        while True:
            item = await queue.get()
            if item is None:
                break
            if isinstance(item, BaseException):
                logger.exception('F5-TTS synthesis failed')
                raise item
            yield item

    async def stream_cached(self, clip: CachedInterjection) -> AsyncIterator[TtsAudioChunk]:
        if clip.pcm_s16le:
            yield TtsAudioChunk(pcm_s16le=clip.pcm_s16le, sample_rate=clip.sample_rate)
