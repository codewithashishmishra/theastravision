"""Fine-tune Whisper on manifest.tsv and export CTranslate2 for faster-whisper."""

from __future__ import annotations

import argparse
import csv
import logging
from pathlib import Path

from config import (
    TRAINING_CHECKPOINTS_ROOT,
    TRAINING_DATA_ROOT,
    WHISPER_FINETUNE_BASE,
    WHISPER_FINETUNE_EPOCHS,
)
from engines.stt_model_registry import set_stt_model
from training.job_runner import get_job, upsert_job

logger = logging.getLogger(__name__)


def _load_manifest(language: str) -> list[tuple[str, str]]:
    manifest = Path(TRAINING_DATA_ROOT) / language / 'manifest.tsv'
    if not manifest.is_file():
        raise FileNotFoundError(f'Missing manifest: {manifest}')
    root = Path(TRAINING_DATA_ROOT).resolve()
    rows: list[tuple[str, str]] = []
    with manifest.open(encoding='utf-8') as f:
        for row in csv.reader(f, delimiter='\t'):
            if len(row) < 2:
                continue
            rel, text = row[0].strip(), row[1].strip()
            if not text:
                continue
            wav = (root / rel).resolve()
            if wav.is_file():
                rows.append((str(wav), text))
    if not rows:
        raise ValueError('Manifest has no valid rows')
    return rows


def _finetune_hf(rows: list[tuple[str, str]], language: str, out_hf: Path) -> None:
    import torch
    from datasets import Dataset
    from transformers import (
        Seq2SeqTrainer,
        Seq2SeqTrainingArguments,
        WhisperForConditionalGeneration,
        WhisperProcessor,
    )

    whisper_lang = 'hi' if language == 'hinglish' else language
    processor = WhisperProcessor.from_pretrained(WHISPER_FINETUNE_BASE)
    model = WhisperForConditionalGeneration.from_pretrained(WHISPER_FINETUNE_BASE)
    model.config.forced_decoder_ids = processor.get_decoder_prompt_ids(
        language=whisper_lang, task='transcribe'
    )

    def _prepare(batch):
        import librosa
        import numpy as np

        audio, _ = librosa.load(batch['audio'], sr=16000, mono=True)
        batch['input_features'] = processor(
            audio, sampling_rate=16000, return_tensors='pt'
        ).input_features[0].numpy()
        batch['labels'] = processor.tokenizer(batch['text']).input_ids
        return batch

    ds = Dataset.from_dict({'audio': [r[0] for r in rows], 'text': [r[1] for r in rows]})
    ds = ds.map(_prepare)

    args = Seq2SeqTrainingArguments(
        output_dir=str(out_hf),
        per_device_train_batch_size=2,
        gradient_accumulation_steps=4,
        num_train_epochs=WHISPER_FINETUNE_EPOCHS,
        learning_rate=1e-5,
        fp16=torch.cuda.is_available(),
        save_strategy='epoch',
        logging_steps=10,
        remove_unused_columns=False,
        label_names=['labels'],
        report_to=[],
    )
    trainer = Seq2SeqTrainer(
        model=model,
        args=args,
        train_dataset=ds,
        processing_class=processor,
    )
    trainer.train()
    model.save_pretrained(out_hf)
    processor.save_pretrained(out_hf)


def _export_ct2(hf_dir: Path, ct2_dir: Path) -> None:
    ct2_dir.mkdir(parents=True, exist_ok=True)
    try:
        from ctranslate2.converters import TransformersConverter

        TransformersConverter(str(hf_dir)).convert(
            str(ct2_dir),
            quantization='float16',
            force=True,
        )
    except Exception as exc:
        logger.warning('CT2 export failed (%s); copying HF weights only', exc)
        import shutil

        if ct2_dir.exists():
            shutil.rmtree(ct2_dir)
        shutil.copytree(hf_dir, ct2_dir)


def run_job(job_id: str) -> None:
    job = get_job(job_id)
    if not job:
        raise ValueError(f'Unknown job {job_id}')
    language = job.language
    job.status = 'preprocessing'
    upsert_job(job)

    rows = _load_manifest(language)
    job.sample_count = len(rows)
    job.hours = round(sum(Path(p).stat().st_size for p, _ in rows) / (16000 * 2 * 3600), 3)
    job.status = 'training'
    upsert_job(job)

    ckpt_root = Path(TRAINING_CHECKPOINTS_ROOT) / language
    hf_dir = ckpt_root / 'hf'
    ct2_dir = ckpt_root / 'ct2'
    hf_dir.mkdir(parents=True, exist_ok=True)

    _finetune_hf(rows, language, hf_dir)
    _export_ct2(hf_dir, ct2_dir)

    rel_ct2 = str(ct2_dir.relative_to(Path(__file__).resolve().parents[1]))
    set_stt_model(
        language,
        whisper_path=rel_ct2.replace('\\', '/'),
        job_id=job_id,
        ready=True,
        sample_count=job.sample_count,
        hours=job.hours,
    )
    job.status = 'ready'
    job.whisper_path = rel_ct2
    upsert_job(job)
    logger.info('Training job %s ready at %s', job_id, ct2_dir)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--job-id', required=True)
    parser.add_argument('--language', default=None)
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO)
    try:
        run_job(args.job_id)
    except Exception as exc:
        job = get_job(args.job_id)
        if job:
            job.status = 'failed'
            job.error = str(exc)[:2000]
            upsert_job(job)
        raise


if __name__ == '__main__':
    main()
